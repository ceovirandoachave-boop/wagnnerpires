/* Service worker: faz as requisições ao CRM (fora da CSP do WhatsApp Web). */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "VAC_FETCH") {
    fetch(msg.url, msg.options || {})
      .then(async (r) => {
        const body = await r.text();
        sendResponse({ ok: r.ok, status: r.status, body: body });
      })
      .catch((e) => sendResponse({ ok: false, status: 0, error: e.message }));
    return true; // resposta assíncrona
  }
});
