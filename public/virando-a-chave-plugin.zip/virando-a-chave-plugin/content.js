/* Injetor + ponte de rede (mundo isolado). */
(function () {
  // ponte: recebe pedidos do app (mundo da página) e faz o fetch pelo background
  window.addEventListener("message", function (e) {
    if (e.source !== window || !e.data || e.data.__vac !== "req") return;
    chrome.runtime.sendMessage({ type: "VAC_FETCH", url: e.data.url, options: e.data.options }, function (resp) {
      const err = chrome.runtime.lastError;
      window.postMessage({ __vac: "res", id: e.data.id, resp: resp || { ok: false, status: 0, error: err ? err.message : "sem resposta" } }, "*");
    });
  });

  function inject(file) {
    return new Promise(function (resolve) {
      try {
        const s = document.createElement("script");
        s.src = chrome.runtime.getURL(file);
        s.async = false;
        s.onload = function () { this.remove(); resolve(); };
        s.onerror = function () { resolve(); };
        (document.head || document.documentElement).appendChild(s);
      } catch (e) { resolve(); }
    });
  }
  function waitFor(sel, cb) {
    if (document.querySelector(sel)) return cb();
    const o = new MutationObserver(function () {
      if (document.querySelector(sel)) { o.disconnect(); cb(); }
    });
    o.observe(document.documentElement, { childList: true, subtree: true });
  }
  waitFor("#app", async function () {
    await inject("assets/wa-js.js");
    await inject("assets/vac-app.js");
  });
})();
