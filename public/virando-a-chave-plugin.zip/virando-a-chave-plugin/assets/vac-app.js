/* Virando a Chave — app (mundo da página): CRM Kanban sobre as conversas reais do WhatsApp (WA-JS) */
(function () {
  if (window.__VAC_APP_LOADED__) return;
  window.__VAC_APP_LOADED__ = true;

  const SIDE = 58;
  const TOPH = 46;
  const LEADW = 360;
  const LS = "vac-leads-v4"; // { chatId: { stage, etiqueta, checklist:{}, telefone, instagram, site, email, cidade } }
  const INBOX_CAP = 80;
  const COLUMNS = [
    { id: "conversas", name: "Conversas", color: "#22c55e" },
    { id: "andamento", name: "Andamento", color: "#3b82f6" },
    { id: "pendentes", name: "Pendentes", color: "#f59e0b" },
    { id: "concluidas", name: "Concluídas", color: "#10b981" },
  ];
  const ETIQUETAS = [
    { id: "andamento", name: "Em andamento", color: "#f59e0b" },
    { id: "naoresp", name: "Não respondeu", color: "#ef4444" },
    { id: "finalizado", name: "Finalizado", color: "#22c55e" },
  ];
  const CHECKS = [
    { id: "msg", name: "Primeira mensagem enviada" },
    { id: "insta", name: "Segui no Instagram" },
    { id: "coment", name: "Comentei no post" },
  ];

  let leads = load();
  let chats = [];
  let open = false;
  let q = "";
  let openId = null; // conversa aberta no modo chat

  function load() {
    try { const r = JSON.parse(localStorage.getItem(LS)); if (r && typeof r === "object") return r; } catch (e) {}
    try { const old = JSON.parse(localStorage.getItem("vac-stages-v3")); if (old) { const m = {}; Object.keys(old).forEach((k) => (m[k] = { stage: old[k] })); return m; } } catch (e) {}
    return {};
  }
  function persist() { try { localStorage.setItem(LS, JSON.stringify(leads)); } catch (e) {} }
  function getLead(id) { return leads[id] || (leads[id] = {}); }
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]));
  const initials = (n) => (String(n || "?").trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "?");
  const fmtT = (t) => { if (!t) return ""; const d = new Date(t * 1000); const now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }) : d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }); };

  // ---------- espera o WA-JS engatar ----------
  let tries = 0;
  const wait = setInterval(() => {
    tries++;
    if (window.WPP && window.WPP.isReady) { clearInterval(wait); start(); }
    else if (window.WPP && window.WPP.webpack && tries === 2) { try { window.WPP.webpack.injectLoader(); } catch (e) {} }
    else if (tries > 160) { clearInterval(wait); console.warn("[VAC] WA-JS não ficou pronto"); }
  }, 500);

  function start() {
    buildShell();
    ensureFab();
    setInterval(updateFab, 1000);
    loadChats().then(() => { renderTopbar(); if (open) renderKanban(); });
    try {
      window.WPP.on("chat.new", refresh);
      window.WPP.on("chat.active_change", refresh);
      window.WPP.on("chat.msg_count", refresh);
    } catch (e) {}
    console.log("[VAC] plugin pronto (WA-JS engatado).");
  }
  let rT = null;
  function refresh() { clearTimeout(rT); rT = setTimeout(() => loadChats().then(() => { renderTopbar(); if (open) renderKanban(); }), 800); }

  // ---------- pega as conversas reais ----------
  async function loadChats() {
    try {
      const list = await window.WPP.chat.list();
      chats = (list || []).map((c) => {
        let id = "";
        try { id = c.id && (c.id._serialized || (c.id.toString && c.id.toString())); } catch (e) {}
        let name = "";
        try { name = c.formattedTitle || c.name || (c.contact && (c.contact.formattedName || c.contact.name || c.contact.pushname)) || ""; } catch (e) {}
        if (!name && id) name = String(id).split("@")[0];
        let preview = "";
        try {
          const last = c.lastMessage || (c.msgs && c.msgs.getLast && c.msgs.getLast());
          preview = (last && (last.body || last.caption)) || "";
        } catch (e) {}
        return { id: id || "", name: name || "?", preview: String(preview || "").slice(0, 90), isGroup: !!c.isGroup, unread: c.unreadCount || 0, t: c.t || 0 };
      }).filter((c) => c.id && !c.id.includes("status@broadcast"));
      chats.sort((a, b) => b.t - a.t);
    } catch (e) { console.warn("[VAC] loadChats erro", e); }
    return chats;
  }

  function stageOf(id) { return (leads[id] && leads[id].stage) || "conversas"; }

  // ---------- shell (sidebar + painel) ----------
  function buildShell() {
    if (document.getElementById("vac-side")) return;
    const side = document.createElement("div");
    side.id = "vac-side";
    side.innerHTML =
      '<div class="vac-logo">C</div>' +
      '<button class="vac-navbtn active" id="vac-nav-crm"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg><span class="vac-lbl">Funil / CRM</span></button>' +
      '<button class="vac-navbtn" id="vac-nav-app"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M3 9h18M8 4v5"/></svg><span class="vac-lbl">Meu App</span></button>' +
      '<div class="vac-spacer"></div>';
    document.body.appendChild(side);
    const topbar = document.createElement("div");
    topbar.id = "vac-topbar";
    document.body.appendChild(topbar);
    const panel = document.createElement("div");
    panel.id = "vac-panel";
    document.body.appendChild(panel);
    document.getElementById("vac-nav-crm").addEventListener("click", toggle);
    document.getElementById("vac-nav-app").addEventListener("click", openApp);
    renderTopbar();
    reserve();
    new MutationObserver(reserve).observe(document.documentElement, { subtree: true, childList: true });
    window.addEventListener("resize", reserve);
    toggle(); // abre já
  }

  function toggle() {
    if (document.getElementById("vac-chatmode")) { exitChatMode(); return; } // estava numa conversa → volta pro CRM
    open = !open;
    document.getElementById("vac-panel").classList.toggle("open", open);
    document.getElementById("vac-nav-crm").classList.toggle("active", open);
    document.getElementById("vac-nav-app").classList.remove("active");
    if (open) renderKanban();
  }

  // ---------- Meu App embarcado (iframe) ----------
  function clearChatMode() {
    const st = document.getElementById("vac-chatmode"); if (st) st.remove();
    const el = document.getElementById("vac-lead"); if (el) el.style.display = "none";
    openId = null; reserve();
  }
  function appUrl() { return localStorage.getItem("vac-app-url") || "https://virandoachave.gestorwagnnerpires.com.br/"; }
  function openApp() {
    clearChatMode();
    open = true;
    document.getElementById("vac-panel").classList.add("open");
    document.getElementById("vac-nav-app").classList.add("active");
    document.getElementById("vac-nav-crm").classList.remove("active");
    renderApp();
  }
  function renderApp() {
    const panel = document.getElementById("vac-panel"); if (!panel) return;
    const url = appUrl();
    panel.innerHTML =
      '<div class="vac-phead"><div><h1>Meu App</h1><div class="vac-sub">' + esc(url.replace(/^https?:\/\//, "").replace(/\/$/, "")) + "</div></div>" +
      '<button class="vac-x" id="vac-app-cfg" title="Trocar endereço">⚙</button>' +
      '<button class="vac-x" id="vac-app-close">×</button></div>' +
      '<div class="vac-pbody"><div class="vac-appbox">' +
        '<div class="vac-appbox-ic">🚀</div>' +
        "<h2>Seu app da Virando a Chave</h2>" +
        "<p>O WhatsApp Web não deixa embutir o app numa mesma tela (proteção dele). Por enquanto o app abre em uma aba ao lado — o CRM nativo (via WA-JS) continua aqui dentro.</p>" +
        '<button class="vac-btn" id="vac-app-open">Abrir Meu App</button>' +
      "</div></div>";
    panel.querySelector("#vac-app-close").onclick = () => { open = false; panel.classList.remove("open"); document.getElementById("vac-nav-app").classList.remove("active"); };
    panel.querySelector("#vac-app-open").onclick = () => { try { window.open(url, "_blank"); } catch (e) { location.href = url; } };
    panel.querySelector("#vac-app-cfg").onclick = () => {
      const u = prompt("Endereço do seu app (ex: https://SEU.gestorwagnnerpires.com.br/):", url);
      if (u && /^https?:\/\//.test(u)) { localStorage.setItem("vac-app-url", u); renderApp(); }
    };
  }

  // o WhatsApp fica deslocado pela sidebar (esquerda) e pela barra de etapas (topo)
  function reserve() {
    const app = document.getElementById("app");
    if (!app) return;
    app.style.setProperty("margin-left", SIDE + "px", "important");
    app.style.setProperty("width", "calc(100vw - " + SIDE + "px)", "important");
    app.style.setProperty("margin-top", TOPH + "px", "important");
    app.style.setProperty("height", "calc(100vh - " + TOPH + "px)", "important");
  }

  // ---------- barra de etapas no topo (contadores + abrir CRM) ----------
  function renderTopbar() {
    const el = document.getElementById("vac-topbar"); if (!el) return;
    const total = chats.length;
    const counts = {}; COLUMNS.forEach((c) => (counts[c.id] = 0));
    chats.forEach((c) => { const s = stageOf(c.id); if (counts[s] != null) counts[s]++; });
    el.innerHTML =
      '<div class="vac-tb-brand">Virando a Chave</div>' +
      '<button class="vac-tb-pill" data-go="1"><span class="vac-tb-n">' + total + "</span> Todos</button>" +
      COLUMNS.map((c) => '<button class="vac-tb-pill" data-go="1" data-col="' + c.id + '"><span class="vac-tb-dot" style="background:' + c.color + '"></span>' + esc(c.name) + ' <span class="vac-tb-n">' + counts[c.id] + "</span></button>").join("") +
      '<div class="vac-tb-sp"></div>';
    el.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => {
      if (!open || document.getElementById("vac-chatmode")) {
        const st = document.getElementById("vac-chatmode"); if (st) { st.remove(); const le = document.getElementById("vac-lead"); if (le) le.style.display = "none"; openId = null; reserve(); }
        open = true;
        document.getElementById("vac-panel").classList.add("open");
        document.getElementById("vac-nav-crm").classList.add("active");
        document.getElementById("vac-nav-app").classList.remove("active");
      }
      renderKanban();
    }));
  }

  // ---------- modo conversa: painel de lead (esquerda) + conversa do WhatsApp (direita) ----------
  function enterChatMode() {
    open = false;
    const panel = document.getElementById("vac-panel");
    if (panel) panel.classList.remove("open");
    document.getElementById("vac-nav-crm").classList.remove("active");
    // esconde a lista lateral do WhatsApp (o painel de lead entra no lugar)
    if (!document.getElementById("vac-chatmode")) {
      const st = document.createElement("style");
      st.id = "vac-chatmode";
      st.textContent = "#side{display:none !important;}";
      (document.head || document.documentElement).appendChild(st);
    }
    let el = document.getElementById("vac-lead");
    if (!el) { el = document.createElement("div"); el.id = "vac-lead"; document.body.appendChild(el); }
    el.style.display = "flex";
    // empurra a conversa pra depois do painel de lead
    const app = document.getElementById("app");
    if (app) {
      app.style.setProperty("margin-left", (SIDE + LEADW) + "px", "important");
      app.style.setProperty("width", "calc(100vw - " + (SIDE + LEADW) + "px)", "important");
    }
    renderLead();
  }
  function exitChatMode() {
    const st = document.getElementById("vac-chatmode"); if (st) st.remove();
    const el = document.getElementById("vac-lead"); if (el) el.style.display = "none";
    openId = null;
    reserve(); // #app volta pro deslocamento só da sidebar
    open = true;
    document.getElementById("vac-panel").classList.add("open");
    document.getElementById("vac-nav-crm").classList.add("active");
    renderKanban();
  }

  // ---------- painel de infos do lead ----------
  function renderLead() {
    const el = document.getElementById("vac-lead"); if (!el || !openId) return;
    const c = chats.find((x) => x.id === openId) || { id: openId, name: (openId || "").split("@")[0] };
    const L = getLead(openId);
    const phone = String(openId || "").split("@")[0].replace(/\D/g, "");
    el.innerHTML =
      '<div class="vac-lead-head"><button class="vac-lead-back" id="vac-lead-back">← CRM</button>' +
        '<div class="vac-lead-tabs"><b class="active">Principal</b></div></div>' +
      '<div class="vac-lead-body">' +
        '<div class="vac-lcard"><div class="vac-lcard-t">CONTATO</div>' +
          '<div class="vac-lf"><span class="vac-lf-k">Nome</span><span class="vac-lf-v" style="font-weight:800">' + esc(c.name) + "</span></div>" +
          leadInput("Telefone", "telefone", L.telefone) +
          '<div class="vac-lf"><span class="vac-lf-k">WhatsApp</span><span class="vac-lf-v" style="color:#2b8cf0;font-weight:700">' + esc(phone) + "</span></div>" +
          leadInput("Instagram", "instagram", L.instagram) +
          leadInput("Site", "site", L.site) +
          leadInput("Email", "email", L.email) +
          leadInput("Cidade", "cidade", L.cidade) +
          '<div class="vac-lf"><span class="vac-lf-k">Coluna</span><select class="vac-lf-sel" id="vac-lf-stage">' +
            COLUMNS.map((k) => '<option value="' + k.id + '" ' + (stageOf(openId) === k.id ? "selected" : "") + ">" + k.name + "</option>").join("") +
          "</select></div>" +
        "</div>" +
        '<div class="vac-lsec">QUALIFICAR LEAD</div>' +
        '<div class="vac-qual"><button class="vac-qbtn q" id="vac-q-ok">✓ Qualificado</button><button class="vac-qbtn n" id="vac-q-no">✗ Desqualificado</button></div>' +
        '<div class="vac-lsec">ETIQUETA</div><div class="vac-etqs">' +
          ETIQUETAS.map((e) => '<button class="vac-etq' + (L.etiqueta === e.id ? " on" : "") + '" data-etq="' + e.id + '"><span class="vac-etq-d" style="background:' + e.color + '"></span>' + e.name + "</button>").join("") +
        "</div>" +
        '<div class="vac-lsec">CHECKLIST</div><div class="vac-chk">' +
          CHECKS.map((ck) => '<label><input type="checkbox" data-chk="' + ck.id + '" ' + (L.checklist && L.checklist[ck.id] ? "checked" : "") + "> " + esc(ck.name) + "</label>").join("") +
        "</div>" +
      "</div>";
    // wiring (sem onclick inline pra evitar problema de aspas)
    el.querySelector("#vac-lead-back").onclick = exitChatMode;
    el.querySelectorAll(".vac-lf-i").forEach((inp) => inp.addEventListener("input", () => { getLead(openId)[inp.dataset.key] = inp.value; persist(); }));
    el.querySelector("#vac-lf-stage").onchange = (e) => { const v = e.target.value; if (v === "conversas") { if (leads[openId]) delete leads[openId].stage; } else getLead(openId).stage = v; persist(); };
    el.querySelectorAll(".vac-etq").forEach((b) => b.addEventListener("click", () => { const L2 = getLead(openId); L2.etiqueta = L2.etiqueta === b.dataset.etq ? "" : b.dataset.etq; persist(); renderLead(); }));
    el.querySelectorAll("[data-chk]").forEach((cb) => cb.addEventListener("change", () => { const L2 = getLead(openId); L2.checklist = L2.checklist || {}; L2.checklist[cb.dataset.chk] = cb.checked; persist(); }));
    el.querySelector("#vac-q-ok").onclick = () => qualifyLead("qualificado");
    el.querySelector("#vac-q-no").onclick = () => qualifyLead("desqualificado");
  }

  // ---------- ponte com o CRM do cliente (login + qualificação) ----------
  // fetch via extensão (background) — a CSP do WhatsApp bloqueia fetch direto pra fora
  let _rid = 0; const _rcb = {};
  window.addEventListener("message", function (e) {
    if (e.source !== window || !e.data || e.data.__vac !== "res") return;
    const cb = _rcb[e.data.id]; if (cb) { delete _rcb[e.data.id]; cb(e.data.resp || {}); }
  });
  function bridgeFetch(url, options) {
    return new Promise(function (resolve) {
      const id = ++_rid; _rcb[id] = resolve;
      window.postMessage({ __vac: "req", id: id, url: url, options: options }, "*");
      setTimeout(function () { if (_rcb[id]) { delete _rcb[id]; resolve({ ok: false, status: 0, error: "timeout" }); } }, 20000);
    });
  }
  function apiBase() { return appUrl().replace(/\/+$/, ""); }
  function getToken() { return localStorage.getItem("vac-token") || ""; }
  async function ensureLogin() {
    if (getToken()) return getToken();
    const user = prompt("CRM — usuário:"); if (!user) return null;
    const pass = prompt("CRM — senha:"); if (pass === null) return null;
    const resp = await bridgeFetch(apiBase() + "/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: user, password: pass }) });
    if (!resp.ok) { alert("Erro ao conectar no CRM: " + (resp.error || ("HTTP " + resp.status))); return null; }
    let j = {}; try { j = JSON.parse(resp.body); } catch (e) {}
    if (j.token) { localStorage.setItem("vac-token", j.token); return j.token; }
    alert("Login falhou: " + (j.error || "verifique usuário/senha")); return null;
  }
  async function doQualify(id, name, status) {
    if (!id) { alert("Abra uma conversa primeiro."); return; }
    const tk = await ensureLogin(); if (!tk) return;
    const phone = String(id || "").split("@")[0].replace(/\D/g, "");
    const resp = await bridgeFetch(apiBase() + "/api/lead-qualify", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tk }, body: JSON.stringify({ name: name || phone, whatsapp: phone, status: status }) });
    if (resp.status === 401) { localStorage.removeItem("vac-token"); alert("Sessão expirada — faça login de novo."); return; }
    if (!resp.ok) { alert("Erro ao qualificar: " + (resp.error || ("HTTP " + resp.status))); return; }
    let j = {}; try { j = JSON.parse(resp.body); } catch (e) {}
    vacToast(status === "qualificado" ? "✓ Qualificado → CRM (" + (j.column || "Qualificada") + ")" : "✗ Desqualificado → CRM");
  }
  function qualifyLead(status) { // pelo painel do lead
    if (!openId) return;
    const c = chats.find((x) => x.id === openId) || { name: "" };
    doQualify(openId, c.name || getLead(openId).nome || "", status);
  }
  function qualifyActive(status) { // pelo botão flutuante (conversa aberta no WhatsApp)
    const info = activeChatInfo();
    if (!info || !info.id) { alert("Abra uma conversa no WhatsApp primeiro."); return; }
    doQualify(info.id, info.name, status);
  }
  function vacToast(msg) { const d = document.createElement("div"); d.className = "vac-toast"; d.textContent = msg; document.body.appendChild(d); setTimeout(() => d.remove(), 2400); }

  // ---------- botão flutuante de qualificação (em qualquer conversa aberta) ----------
  function activeChatInfo() {
    try {
      const a = window.WPP && window.WPP.chat && window.WPP.chat.getActiveChat && window.WPP.chat.getActiveChat();
      if (a) {
        const id = a.id && (a.id._serialized || a.id.toString());
        const name = a.formattedTitle || a.name || (a.contact && (a.contact.formattedName || a.contact.pushname)) || String(id || "").split("@")[0];
        if (id) return { id: id, name: name };
      }
    } catch (e) {}
    // fallback: lê o cabeçalho da conversa no DOM
    try {
      const h = document.querySelector("#main header span[title]");
      if (h) return { id: openId || "", name: (h.getAttribute("title") || h.textContent || "").trim() };
    } catch (e) {}
    return null;
  }
  function ensureFab() {
    if (document.getElementById("vac-fab")) return;
    const f = document.createElement("div");
    f.id = "vac-fab";
    f.innerHTML =
      '<span class="vac-fab-lbl">Qualificar lead:</span>' +
      '<button class="vac-fab-q">✓ Qualificado</button>' +
      '<button class="vac-fab-n">✗ Desqualificado</button>';
    document.body.appendChild(f);
    f.querySelector(".vac-fab-q").onclick = () => qualifyActive("qualificado");
    f.querySelector(".vac-fab-n").onclick = () => qualifyActive("desqualificado");
  }
  function updateFab() {
    const f = document.getElementById("vac-fab"); if (!f) return;
    // mostra só quando há conversa 1:1 aberta e o painel do CRM está fechado
    const hasChat = !!activeChatInfo();
    const crmOpen = document.getElementById("vac-panel") && document.getElementById("vac-panel").classList.contains("open");
    f.style.display = hasChat && !crmOpen ? "flex" : "none";
  }
  function leadInput(label, key, val) {
    return '<div class="vac-lf"><span class="vac-lf-k">' + label + '</span><input class="vac-lf-i" data-key="' + key + '" value="' + esc(val || "") + '" placeholder="—"></div>';
  }

  // ---------- Kanban das conversas reais ----------
  function renderKanban() {
    const panel = document.getElementById("vac-panel");
    if (!panel) return;
    panel.innerHTML =
      '<div class="vac-phead"><div><h1>CRM &amp; Cards</h1><div class="vac-sub">' + chats.length + " conversas do WhatsApp</div></div>" +
      '<button class="vac-x" id="vac-close">×</button></div>' +
      '<div class="vac-pbody">' +
        '<div class="vac-kb-tools"><input id="vac-search" placeholder="Buscar conversa..." style="flex:1;border:1px solid var(--vac-line);border-radius:9px;padding:8px 12px;font-size:13px;outline:none;">' +
          '<button class="vac-btn ghost" id="vac-reload">↻</button></div>' +
        '<div class="vac-kb">' + COLUMNS.map(colHtml).join("") + "</div>" +
      "</div>";
    panel.querySelector("#vac-close").onclick = toggle;
    panel.querySelector("#vac-reload").onclick = () => loadChats().then(renderKanban);
    const s = panel.querySelector("#vac-search");
    s.value = q; s.oninput = () => { q = s.value.toLowerCase(); renderKanban(); panel.querySelector("#vac-search").focus(); };
    wire();
  }

  function colHtml(col) {
    let items = chats.filter((c) => stageOf(c.id) === col.id);
    if (q) items = items.filter((c) => c.name.toLowerCase().includes(q));
    const total = items.length;
    if (col.id === "conversas") items = items.slice(0, INBOX_CAP);
    return '<div class="vac-col"><div class="vac-col-h"><span class="vac-dot" style="background:' + col.color + '"></span>' + esc(col.name) +
      '<span class="vac-cnt">' + total + "</span></div>" +
      '<div class="vac-col-b" data-col="' + col.id + '">' + items.map(cardHtml).join("") +
      (col.id === "conversas" && total > INBOX_CAP ? '<div style="text-align:center;color:var(--vac-txt2);font-size:11px;padding:6px">+' + (total - INBOX_CAP) + " (use a busca)</div>" : "") +
      "</div></div>";
  }

  function cardHtml(c) {
    return '<div class="vac-card" draggable="true" data-id="' + esc(c.id) + '">' +
      '<div class="vac-card-top"><div class="vac-av">' + esc(initials(c.name)) + "</div>" +
      '<div class="vac-card-name">' + esc(c.name) + "</div>" +
      '<span class="vac-card-time">' + esc(fmtT(c.t)) + "</span></div>" +
      (c.preview ? '<div class="vac-card-msg">' + esc(c.preview) + "</div>" : "") +
      '<div class="vac-card-foot"><span class="vac-tag">' + (c.isGroup ? "Grupo" : "Lead") + "</span>" +
      (c.unread ? '<span class="vac-tag" style="background:#dcfce7;color:#166534">' + c.unread + " novas</span>" : "") +
      '<span class="vac-assign">abrir ↗</span></div></div>';
  }

  function wire() {
    const panel = document.getElementById("vac-panel");
    let dragId = null;
    panel.querySelectorAll(".vac-card").forEach((el) => {
      el.addEventListener("dragstart", () => { dragId = el.dataset.id; el.style.opacity = ".4"; });
      el.addEventListener("dragend", () => { el.style.opacity = ""; dragId = null; });
      el.addEventListener("click", (e) => { if (e.target.closest("[draggable]") && !dragId) openChat(el.dataset.id); });
    });
    panel.querySelectorAll(".vac-col-b").forEach((body) => {
      body.addEventListener("dragover", (e) => { e.preventDefault(); body.classList.add("drag"); });
      body.addEventListener("dragleave", () => body.classList.remove("drag"));
      body.addEventListener("drop", (e) => {
        e.preventDefault(); body.classList.remove("drag");
        if (!dragId) return;
        const col = body.dataset.col;
        if (col === "conversas") { if (leads[dragId]) delete leads[dragId].stage; } else getLead(dragId).stage = col;
        persist(); renderKanban(); renderTopbar();
      });
    });
  }

  function openChat(id) {
    openId = id;
    try { window.WPP.chat.openChatBottom(id); } catch (e) { try { window.WPP.chat.openChatAt(id); } catch (e2) {} }
    enterChatMode();
  }
})();
