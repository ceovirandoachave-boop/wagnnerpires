# Virando a Chave — CRM sobre o WhatsApp Web

Extensão Chrome que engata no **motor interno do WhatsApp Web** (via WA-JS) e
adiciona, na borda esquerda, um **funil de CRM (Kanban)** com as **conversas reais**.

## v0.3 — o que faz

- Sidebar fixa à esquerda; o WhatsApp é empurrado (não sobrepõe).
- **CRM & Cards (Kanban):** colunas Conversas / Andamento / Pendentes / Concluídas
  com as **conversas reais** do seu WhatsApp.
- **Arrastar** um card muda a etapa da conversa (salvo por conversa).
- **Clicar** num card **abre a conversa** no WhatsApp Web ao lado.
- Busca de conversas.

## Instalar

1. Extraia o `.zip`.
2. `chrome://extensions` → **Modo do desenvolvedor**.
3. **Carregar sem compactação** → selecione a pasta `virando-a-chave-plugin`.
4. Abra `https://web.whatsapp.com` (aguarde uns segundos pro WA-JS engatar).
